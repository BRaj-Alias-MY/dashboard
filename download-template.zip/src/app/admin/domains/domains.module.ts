import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DomainsRoutingModule } from './domains-routing.module';
import { DomainsComponent } from './domains.component';

@NgModule({
 
  imports: [
    CommonModule,
    DomainsRoutingModule
  ],
  declarations: [DomainsComponent]
})
export class DomainsModule { }
