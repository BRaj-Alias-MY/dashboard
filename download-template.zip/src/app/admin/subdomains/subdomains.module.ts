import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SubdomainsRoutingModule } from './subdomains-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SubdomainsRoutingModule
  ]
})
export class SubdomainsModule { }
