import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminComponent } from './admin.component';

 
const routes: Routes = [
  {
      path: '',
      component: AdminComponent,
      children: [
          {
              path: 'domains',
              loadChildren: './domains/domains.module#DomainsModule'
          },
          
          {
              path: 'subdomains',
              loadChildren: './subdomains/subdomains.module#SubdomainsModule'
          }
      ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
